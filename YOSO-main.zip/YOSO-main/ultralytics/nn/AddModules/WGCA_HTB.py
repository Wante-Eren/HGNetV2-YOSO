import torch.nn.functional as F
import numbers
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

Conv2d = nn.Conv2d


def to_2d(x):
    return rearrange(x, 'b c h w -> b (h w c)')


def to_3d(x):
    #    return rearrange(x, 'b c h w -> b c (h w)')
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    #    return rearrange(x, 'b c (h w) -> b c h w',h=h,w=w)
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5)  # * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5)  # * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type="WithBias"):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


##########################################################################
## Dual-scale Gated Feed-Forward Network (DGFF)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.project_in = Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)

        self.dwconv_5 = Conv2d(hidden_features // 4, hidden_features // 4, kernel_size=5, stride=1, padding=2,
                               groups=hidden_features // 4, bias=bias)
        self.dwconv_dilated2_1 = Conv2d(hidden_features // 4, hidden_features // 4, kernel_size=3, stride=1, padding=2,
                                        groups=hidden_features // 4, bias=bias, dilation=2)
        self.p_unshuffle = nn.PixelUnshuffle(2)
        self.p_shuffle = nn.PixelShuffle(2)

        self.project_out = Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x = self.p_shuffle(x)
        x1, x2 = x.chunk(2, dim=1)
        x1 = self.dwconv_5(x1)
        x2 = self.dwconv_dilated2_1(x2)
        x = F.mish(x2) * x1
        x = self.p_unshuffle(x)
        x = self.project_out(x)
        return x


##########################################################################
##Dynamic-range Histogram Self-Attention (DHSA)
class Attention_histogram(nn.Module):
    def __init__(self, dim, num_heads=4, bias=False, ifBox=True):
        super(Attention_histogram, self).__init__()
        self.factor = num_heads
        self.ifBox = ifBox
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = Conv2d(dim, dim * 5, kernel_size=1, bias=bias)
        self.qkv_dwconv = Conv2d(dim * 5, dim * 5, kernel_size=3, stride=1, padding=1, groups=dim * 5, bias=bias)
        self.project_out = Conv2d(dim, dim, kernel_size=1, bias=bias)

    def pad(self, x, factor):
        hw = x.shape[-1]
        t_pad = [0, 0] if hw % factor == 0 else [0, (hw // factor + 1) * factor - hw]
        x = F.pad(x, t_pad, 'constant', 0)
        return x, t_pad

    def unpad(self, x, t_pad):
        _, _, hw = x.shape
        return x[:, :, t_pad[0]:hw - t_pad[1]]

    def softmax_1(self, x, dim=-1):
        logit = x.exp()
        logit = logit / (logit.sum(dim, keepdim=True) + 1)
        return logit

    def normalize(self, x):
        mu = x.mean(-2, keepdim=True)
        sigma = x.var(-2, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5)  # * self.weight + self.bias

    def reshape_attn(self, q, k, v, ifBox):
        b, c = q.shape[:2]
        q, t_pad = self.pad(q, self.factor)
        k, t_pad = self.pad(k, self.factor)
        v, t_pad = self.pad(v, self.factor)
        hw = q.shape[-1] // self.factor
        shape_ori = "b (head c) (factor hw)" if ifBox else "b (head c) (hw factor)"
        shape_tar = "b head (c factor) hw"
        q = rearrange(q, '{} -> {}'.format(shape_ori, shape_tar), factor=self.factor, hw=hw, head=self.num_heads)
        k = rearrange(k, '{} -> {}'.format(shape_ori, shape_tar), factor=self.factor, hw=hw, head=self.num_heads)
        v = rearrange(v, '{} -> {}'.format(shape_ori, shape_tar), factor=self.factor, hw=hw, head=self.num_heads)
        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = self.softmax_1(attn, dim=-1)
        out = (attn @ v)
        out = rearrange(out, '{} -> {}'.format(shape_tar, shape_ori), factor=self.factor, hw=hw, b=b,
                        head=self.num_heads)
        out = self.unpad(out, t_pad)
        return out

    def forward(self, x):
        b, c, h, w = x.shape
        x_sort, idx_h = x[:, :c // 2].sort(-2)
        x_sort, idx_w = x_sort.sort(-1)
        x[:, :c // 2] = x_sort
        qkv = self.qkv_dwconv(self.qkv(x))
        q1, k1, q2, k2, v = qkv.chunk(5, dim=1)  # b,c,x,x

        v, idx = v.view(b, c, -1).sort(dim=-1)
        q1 = torch.gather(q1.view(b, c, -1), dim=2, index=idx)
        k1 = torch.gather(k1.view(b, c, -1), dim=2, index=idx)
        q2 = torch.gather(q2.view(b, c, -1), dim=2, index=idx)
        k2 = torch.gather(k2.view(b, c, -1), dim=2, index=idx)

        out1 = self.reshape_attn(q1, k1, v, True)
        out2 = self.reshape_attn(q2, k2, v, False)

        out1 = torch.scatter(out1, 2, idx, out1).view(b, c, h, w)
        out2 = torch.scatter(out2, 2, idx, out2).view(b, c, h, w)
        out = out1 * out2
        out = self.project_out(out)
        out_replace = out[:, :c // 2]
        out_replace = torch.scatter(out_replace, -1, idx_w, out_replace)
        out_replace = torch.scatter(out_replace, -2, idx_h, out_replace)
        out[:, :c // 2] = out_replace
        return out


##########################################################################
##Histogram Transformer Block (HTB)
class HTB(nn.Module):
    def __init__(self, dim, num_heads=4, ffn_expansion_factor=2.5, bias=False,
                 LayerNorm_type='WithBias'):  ## Other option 'BiasFree'
        super(HTB, self).__init__()
        self.attn_g = Attention_histogram(dim, num_heads, bias, True)
        self.norm_g = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(dim, ffn_expansion_factor, bias)

        self.norm_ff1 = LayerNorm(dim, LayerNorm_type)

    def forward(self, x):
        x = x + self.attn_g(self.norm_g(x))
        x_out = x + self.ffn(self.norm_ff1(x))

        return x_out

class HaarWavelet(nn.Module):
    """修复版Haar小波变换"""

    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels

        # 更安全的权重初始化
        weights = torch.tensor([
            [1, 1, 1, 1],
            [1, -1, 1, -1],
            [1, 1, -1, -1],
            [1, -1, -1, 1]
        ], dtype=torch.float32)

        # 关键修复：调整权重形状为[4*in_channels, 1, 2, 2]
        weights = weights.view(4, 1, 2, 2)
        weights = weights.repeat(in_channels, 1, 1, 1)  # [4*in_channels, 1, 2, 2]
        self.register_buffer('weights', weights)
        self.groups = in_channels  # 分组数等于输入通道数

    def forward(self, x, rev=False):
        if not rev:
            # 正向变换
            B, C, H, W = x.shape
            pad_h, pad_w = (2 - H % 2) % 2, (2 - W % 2) % 2
            if pad_h or pad_w:
                x = F.pad(x, (0, pad_w, 0, pad_h))
            # 输出通道数变为4*C
            return F.conv2d(x, self.weights, stride=2, groups=self.groups) / 2.0
        else:
            # 逆向变换
            return F.conv_transpose2d(x, self.weights, stride=2, groups=self.groups)


class WaveletProcessor(nn.Module):
    """轻量级小波处理器"""

    def __init__(self, in_channels, wavelet_type='haar'):
        super().__init__()
        self.in_channels = in_channels
        self.wavelet = HaarWavelet(in_channels)

        # 限制最大通道数防止显存爆炸
        max_channels = min(4 * in_channels, 1024)
        self.process = nn.Sequential(
            nn.Conv2d(4 * in_channels, max_channels, 1, groups=4),
            nn.ReLU(),
            nn.Conv2d(max_channels, 4 * in_channels, 1, groups=4)
        )
        # 移除recon层，因为重构后通道数自动匹配

    def forward(self, x):
        orig_size = x.shape[2:]

        # 小波分解
        decomposed = self.wavelet(x, rev=False)  # 输出[B, 4*C, H/2, W/2]

        # 特征处理
        processed = self.process(decomposed)  # 输出[B, 4*C, H/2, W/2]

        # 小波重构
        reconstructed = self.wavelet(processed, rev=True)  # 输出[B, C, H, W]

        # 尺寸对齐
        if reconstructed.shape[2:] != orig_size:
            reconstructed = reconstructed[:, :, :orig_size[0], :orig_size[1]]

        return x + reconstructed


class EfficientCrossAttention(nn.Module):
    """显存高效的交叉注意力"""

    def __init__(self, channels, num_heads=4):
        super().__init__()
        self.num_heads = min(num_heads, channels)
        self.head_dim = max(1, channels // self.num_heads)
        self.scale = self.head_dim ** -0.5 if self.head_dim > 0 else 1.0

        self.q_proj = nn.Conv2d(channels, channels, 1)
        self.k_proj = nn.Conv2d(channels, channels, 1)
        self.v_proj = nn.Conv2d(channels, channels, 1)
        self.out_proj = nn.Conv2d(channels, channels, 1)

    def forward(self, x):
        ir = x[0]
        vis = x[1]

        # 投影
        q = self.q_proj(ir).view(B, self.num_heads, self.head_dim, H * W)
        k = self.k_proj(vis).view(B, self.num_heads, self.head_dim, H * W)
        v = self.v_proj(vis).view(B, self.num_heads, self.head_dim, H * W)

        # 注意力计算
        attn = torch.einsum('bhdk,bhek->bhde', q, k) * self.scale
        attn = F.softmax(attn, dim=-1)
        out = torch.einsum('bhde,bhek->bhdk', attn, v)

        # 合并多头
        out = out.permute(0, 2, 1, 3).contiguous().view(B, C, H, W)
        return self.out_proj(out)


class GlobalContextBranch(nn.Module):
    """全局上下文分支"""

    def __init__(self, channels):
        super().__init__()
        self.cross_attn = EfficientCrossAttention(channels)
        self.min_channels = max(4, channels // 8)

        # 共享基础卷积
        self.base_conv = nn.Conv2d(channels, self.min_channels, 3, padding=1)

        # 多尺度卷积
        self.dilated_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(self.min_channels, self.min_channels, 3,
                          padding=d, dilation=d, groups=self.min_channels),
                nn.BatchNorm2d(self.min_channels),
                nn.ReLU()
            ) for d in [1, 2, 4]
        ])

        # 特征增强
        self.enhance = nn.Sequential(
            nn.Conv2d(channels + 3 * self.min_channels, channels, 1),
            nn.InstanceNorm2d(channels),
            nn.GELU()
        )

    def forward(self, ir, vis):
        # 交叉注意力融合
        fused = self.cross_attn(ir, vis)

        # 多尺度特征提取
        x = self.base_conv(fused)
        features = [conv(x) for conv in self.dilated_convs]
        multi_scale = torch.cat(features, dim=1)

        # 残差增强
        combined = torch.cat([fused, multi_scale], dim=1)
        return fused + self.enhance(combined)


class SE_Block(nn.Module):
    """压缩-激励注意力"""

    def __init__(self, inchannel, ratio=16):
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(inchannel, max(1, inchannel // ratio)),
            nn.ReLU(),
            nn.Linear(max(1, inchannel // ratio), inchannel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c = x.shape[:2]
        y = self.gap(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y


class WGCAHTB(nn.Module):
    """完整的多模态融合网络"""

    def __init__(self, channels):
        super().__init__()
        # 确保channels是整数
        if isinstance(channels, list):
            channels = channels[0]  # 取列表中的第一个元素作为通道数
        elif isinstance(channels, tuple):
            channels = channels[0]

        assert isinstance(channels, int), f"通道数应为整数, 实际类型为{type(channels)}"
        assert channels >= 4, f"通道数不能小于4, 当前为{channels}"

        self.channels = channels

        # 模态处理器
        self.ir_processor = WaveletProcessor(channels)
        self.vis_processor = WaveletProcessor(channels)

        # 特征融合分支
        self.global_branch = GlobalContextBranch(channels)
        self.se_block = SE_Block(channels)

        # 自适应融合
        self.gamma = nn.Parameter(torch.tensor(0.5))

        # Mamba模块
        self.htb = HTB(dim=channels)

        #注意力融合
        self.atten_fusion = EfficientCrossAttention(channels=channels)
    def forward(self, inputs):
        """支持多种输入格式：
        - List/Tuple: [ir_tensor, vis_tensor]
        - Dict: {'ir': ir_tensor, 'vis': vis_tensor}
        """
        if isinstance(inputs, (list, tuple)):
            ir, vis = inputs
        elif isinstance(inputs, dict):
            ir, vis = inputs['ir'], inputs['vis']
        else:
            raise ValueError("输入应为[ir,vis]或{'ir':tensor,'vis':tensor}")

        # 尺寸验证
        assert ir.shape == vis.shape, f"输入尺寸不匹配: IR {ir.shape} != VIS {vis.shape}"

        # 模态处理
        ir_feat = self.ir_processor(ir)
        vis_feat = self.vis_processor(vis)

        # 小波分支
        wavelet = ir_feat + vis_feat
        wavelet_out = self.se_block(wavelet)

        # 全局分支
        global_out = self.global_branch(ir_feat, vis_feat)

        # 动态融合
        blended = self.atten_fusion(wavelet_out, global_out)

        # 特征增强
        return self.htb(blended)