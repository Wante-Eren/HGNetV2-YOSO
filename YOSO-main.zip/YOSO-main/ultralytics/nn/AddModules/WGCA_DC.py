import pywt
import pywt.data
import torch
from torch import nn
from functools import partial
import torch.nn.functional as F


# 论文地址 https://arxiv.org/pdf/2407.05848
def create_wavelet_filter(wave, in_size, out_size, type=torch.float):
    w = pywt.Wavelet(wave)
    dec_hi = torch.tensor(w.dec_hi[::-1], dtype=type)
    dec_lo = torch.tensor(w.dec_lo[::-1], dtype=type)
    dec_filters = torch.stack([dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)], dim=0)

    dec_filters = dec_filters[:, None].repeat(in_size, 1, 1, 1)

    rec_hi = torch.tensor(w.rec_hi[::-1], dtype=type).flip(dims=[0])
    rec_lo = torch.tensor(w.rec_lo[::-1], dtype=type).flip(dims=[0])
    rec_filters = torch.stack([rec_lo.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_lo.unsqueeze(0) * rec_hi.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_hi.unsqueeze(1)], dim=0)

    rec_filters = rec_filters[:, None].repeat(out_size, 1, 1, 1)

    return dec_filters, rec_filters


def wavelet_transform(x, filters):
    b, c, h, w = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = F.conv2d(x, filters, stride=2, groups=c, padding=pad)
    x = x.reshape(b, c, 4, h // 2, w // 2)
    return x


def inverse_wavelet_transform(x, filters):
    b, c, _, h_half, w_half = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = x.reshape(b, c * 4, h_half, w_half)
    x = F.conv_transpose2d(x, filters, stride=2, groups=c, padding=pad)
    return x


# Wavelet Transform Conv(WTConv2d)
class WTConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=5, stride=1, bias=True, wt_levels=1, wt_type='db1'):
        super().__init__()
        assert in_channels == out_channels  # 确保输入输出通道一致
        self.in_channels = in_channels
        self.wt_levels = wt_levels
        self.stride = stride  # 必须为1以保持形状
        self.dilation = 1

        # 初始化小波滤波器（保持不变）
        self.wt_filter, self.iwt_filter = create_wavelet_filter(wt_type, in_channels, in_channels, torch.float)
        self.wt_filter = nn.Parameter(self.wt_filter, requires_grad=False)
        self.iwt_filter = nn.Parameter(self.iwt_filter, requires_grad=False)

        self.wt_function = partial(wavelet_transform, filters=self.wt_filter)
        self.iwt_function = partial(inverse_wavelet_transform, filters=self.iwt_filter)

        # 基础卷积（保持不变）
        self.base_conv = nn.Conv2d(in_channels, in_channels, kernel_size, padding='same', stride=1, dilation=1,
                                 groups=in_channels, bias=bias)
        self.base_scale = _ScaleModule([1, in_channels, 1, 1])

        # 小波卷积（保持不变）
        self.wavelet_convs = nn.ModuleList([
            nn.Conv2d(in_channels * 4, in_channels * 4, kernel_size, padding='same', stride=1, dilation=1,
                     groups=in_channels * 4, bias=False) for _ in range(self.wt_levels)
        ])
        self.wavelet_scale = nn.ModuleList([
            _ScaleModule([1, in_channels * 4, 1, 1], init_scale=0.1) for _ in range(self.wt_levels)
        ])

    def forward(self, x):
        # 动态填充以确保尺寸能被 2^wt_levels 整除
        h, w = x.shape[2], x.shape[3]
        pad_h = (2**self.wt_levels - h % 2**self.wt_levels) % 2**self.wt_levels
        pad_w = (2**self.wt_levels - w % 2**self.wt_levels) % 2**self.wt_levels
        x_padded = F.pad(x, (0, pad_w, 0, pad_h)) if (pad_h > 0 or pad_w > 0) else x

        # 原forward逻辑（保持不变）
        x_ll_in_levels = []
        x_h_in_levels = []
        shapes_in_levels = []
        curr_x_ll = x_padded

        for i in range(self.wt_levels):
            curr_shape = curr_x_ll.shape
            shapes_in_levels.append(curr_shape)
            curr_x = self.wt_function(curr_x_ll)
            curr_x_ll = curr_x[:, :, 0, :, :]
            shape_x = curr_x.shape
            curr_x_tag = curr_x.reshape(shape_x[0], shape_x[1] * 4, shape_x[3], shape_x[4])
            curr_x_tag = self.wavelet_scale[i](self.wavelet_convs[i](curr_x_tag))
            curr_x_tag = curr_x_tag.reshape(shape_x)
            x_ll_in_levels.append(curr_x_tag[:, :, 0, :, :])
            x_h_in_levels.append(curr_x_tag[:, :, 1:4, :, :])

        next_x_ll = 0
        for i in range(self.wt_levels - 1, -1, -1):
            curr_x_ll = x_ll_in_levels.pop()
            curr_x_h = x_h_in_levels.pop()
            curr_shape = shapes_in_levels.pop()
            curr_x_ll = curr_x_ll + next_x_ll
            curr_x = torch.cat([curr_x_ll.unsqueeze(2), curr_x_h], dim=2)
            next_x_ll = self.iwt_function(curr_x)

        x_tag = next_x_ll[:, :, :h, :w]  # 裁剪回原始尺寸
        x = self.base_scale(self.base_conv(x))
        x = x + x_tag
        return x


class _ScaleModule(nn.Module):
    def __init__(self, dims, init_scale=1.0, init_bias=0):
        super(_ScaleModule, self).__init__()
        self.dims = dims
        self.weight = nn.Parameter(torch.ones(*dims) * init_scale)
        self.bias = None

    def forward(self, x):
        return torch.mul(self.weight, x)


class DC2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3):
        super(DC2d, self).__init__()

        # 深度卷积：使用 WTConv2d 替换 3x3 卷积
        self.depthwise = WTConv2d(in_channels, in_channels, kernel_size=kernel_size)

        # 逐点卷积：使用 1x1 卷积
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x
class HaarWavelet(nn.Module):
    """修复版Haar小波变换"""

    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels

        # 更安全的权重初始化
        weights = torch.tensor([
            [1, 1, 1, 1],
            [1, -1, 1, -1],
            [1, 1, -1, -1],
            [1, -1, -1, 1]
        ], dtype=torch.float32)

        # 关键修复：调整权重形状为[4*in_channels, 1, 2, 2]
        weights = weights.view(4, 1, 2, 2)
        weights = weights.repeat(in_channels, 1, 1, 1)  # [4*in_channels, 1, 2, 2]
        self.register_buffer('weights', weights)
        self.groups = in_channels  # 分组数等于输入通道数

    def forward(self, x, rev=False):
        if not rev:
            # 正向变换
            B, C, H, W = x.shape
            pad_h, pad_w = (2 - H % 2) % 2, (2 - W % 2) % 2
            if pad_h or pad_w:
                x = F.pad(x, (0, pad_w, 0, pad_h))
            # 输出通道数变为4*C
            return F.conv2d(x, self.weights, stride=2, groups=self.groups) / 2.0
        else:
            # 逆向变换
            return F.conv_transpose2d(x, self.weights, stride=2, groups=self.groups)


class WaveletProcessor(nn.Module):
    """轻量级小波处理器"""

    def __init__(self, in_channels, wavelet_type='haar'):
        super().__init__()
        self.in_channels = in_channels
        self.wavelet = HaarWavelet(in_channels)

        # 限制最大通道数防止显存爆炸
        max_channels = min(4 * in_channels, 1024)
        self.process = nn.Sequential(
            nn.Conv2d(4 * in_channels, max_channels, 1, groups=4),
            nn.ReLU(),
            nn.Conv2d(max_channels, 4 * in_channels, 1, groups=4)
        )
        # 移除recon层，因为重构后通道数自动匹配

    def forward(self, x):
        orig_size = x.shape[2:]

        # 小波分解
        decomposed = self.wavelet(x, rev=False)  # 输出[B, 4*C, H/2, W/2]

        # 特征处理
        processed = self.process(decomposed)  # 输出[B, 4*C, H/2, W/2]

        # 小波重构
        reconstructed = self.wavelet(processed, rev=True)  # 输出[B, C, H, W]

        # 尺寸对齐
        if reconstructed.shape[2:] != orig_size:
            reconstructed = reconstructed[:, :, :orig_size[0], :orig_size[1]]

        return x + reconstructed


class EfficientCrossAttention(nn.Module):
    """显存高效的交叉注意力"""

    def __init__(self, channels, num_heads=4):
        super().__init__()

        self.num_heads = min(num_heads, channels)
        self.head_dim = max(1, channels // self.num_heads)
        self.scale = self.head_dim ** -0.5 if self.head_dim > 0 else 1.0

        self.q_proj = nn.Conv2d(channels, channels, 1)
        self.k_proj = nn.Conv2d(channels, channels, 1)
        self.v_proj = nn.Conv2d(channels, channels, 1)
        self.out_proj = nn.Conv2d(channels, channels, 1)

    def forward(self, ir,vis):
        B, C, H, W = ir.size()

        # 投影
        q = self.q_proj(ir).view(B, self.num_heads, self.head_dim, H * W)
        k = self.k_proj(vis).view(B, self.num_heads, self.head_dim, H * W)
        v = self.v_proj(vis).view(B, self.num_heads, self.head_dim, H * W)

        # 注意力计算
        attn = torch.einsum('bhdk,bhek->bhde', q, k) * self.scale
        attn = F.softmax(attn, dim=-1)
        out = torch.einsum('bhde,bhek->bhdk', attn, v)

        # 合并多头
        out = out.permute(0, 2, 1, 3).contiguous().view(B, C, H, W)
        return self.out_proj(out)


class GlobalContextBranch(nn.Module):
    """全局上下文分支"""

    def __init__(self, channels):
        super().__init__()
        self.cross_attn = EfficientCrossAttention(channels)
        self.min_channels = max(4, channels // 8)

        # 共享基础卷积
        self.base_conv = nn.Conv2d(channels, self.min_channels, 3, padding=1)

        # 多尺度卷积
        self.dilated_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(self.min_channels, self.min_channels, 3,
                          padding=d, dilation=d, groups=self.min_channels),
                nn.BatchNorm2d(self.min_channels),
                nn.ReLU()
            ) for d in [1, 2, 4]
        ])

        # 特征增强
        self.enhance = nn.Sequential(
            nn.Conv2d(channels + 3 * self.min_channels, channels, 1),
            nn.InstanceNorm2d(channels),
            nn.GELU()
        )

    def forward(self, ir, vis):
        # 交叉注意力融合
        fused = self.cross_attn(ir, vis)

        # 多尺度特征提取
        x = self.base_conv(fused)
        features = [conv(x) for conv in self.dilated_convs]
        multi_scale = torch.cat(features, dim=1)

        # 残差增强
        combined = torch.cat([fused, multi_scale], dim=1)
        return fused + self.enhance(combined)


class SE_Block(nn.Module):
    """压缩-激励注意力"""

    def __init__(self, inchannel, ratio=16):
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(inchannel, max(1, inchannel // ratio)),
            nn.ReLU(),
            nn.Linear(max(1, inchannel // ratio), inchannel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c = x.shape[:2]
        y = self.gap(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y

class WGCADC(nn.Module):
    """完整的多模态融合网络"""

    def __init__(self, channels):
        super().__init__()
        # 确保channels是整数
        if isinstance(channels, list):
            channels = channels[0]  # 取列表中的第一个元素作为通道数
        elif isinstance(channels, tuple):
            channels = channels[0]

        assert isinstance(channels, int), f"通道数应为整数, 实际类型为{type(channels)}"
        assert channels >= 4, f"通道数不能小于4, 当前为{channels}"

        self.channels = channels

        # 模态处理器
        self.ir_processor = WaveletProcessor(channels)
        self.vis_processor = WaveletProcessor(channels)

        # 特征融合分支
        self.global_branch = GlobalContextBranch(channels)
        self.se_block = SE_Block(channels)

        # 自适应融合
        self.gamma = nn.Parameter(torch.tensor(0.5))

        # DC模块
        self.dc = DC2d(in_channels=channels,out_channels=channels)

    def forward(self, inputs):
        """支持多种输入格式：
        - List/Tuple: [ir_tensor, vis_tensor]
        - Dict: {'ir': ir_tensor, 'vis': vis_tensor}
        """
        if isinstance(inputs, (list, tuple)):
            ir, vis = inputs
        elif isinstance(inputs, dict):
            ir, vis = inputs['ir'], inputs['vis']
        else:
            raise ValueError("输入应为[ir,vis]或{'ir':tensor,'vis':tensor}")

        # 尺寸验证
        assert ir.shape == vis.shape, f"输入尺寸不匹配: IR {ir.shape} != VIS {vis.shape}"

        # 模态处理
        ir_feat = self.ir_processor(ir)
        vis_feat = self.vis_processor(vis)

        # 小波分支
        wavelet = ir_feat + vis_feat
        wavelet_out = self.se_block(wavelet)

        # 全局分支
        global_out = self.global_branch(ir_feat, vis_feat)

        # 动态融合
        blended = self.gamma * wavelet_out + (1 - self.gamma) * global_out

        # 特征增强
        return self.dc(blended)