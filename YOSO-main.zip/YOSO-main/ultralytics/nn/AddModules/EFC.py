import torch
import torch.nn as nn
import torch.nn.functional as F

class EFC(nn.Module):
    """完全自适应通道的交叉注意力（无需任何参数）"""
    def __init__(self):
        super().__init__()
        # 延迟初始化参数
        self._initialized = False
        self.num_heads = None
        self.head_dim = None
        self.scale = None
        
        # 动态创建的层
        self.q_proj = None
        self.k_proj = None 
        self.v_proj = None
        self.out_proj = None

    def _initialize_params(self, channels):
        """根据输入通道数动态初始化"""
        self.num_heads = min(4, channels)  # 最多4个头
        self.head_dim = max(1, channels // self.num_heads)
        self.scale = self.head_dim ** -0.5
        
        # 动态创建层
        self.q_proj = nn.Conv2d(channels, channels, 1)
        self.k_proj = nn.Conv2d(channels, channels, 1)
        self.v_proj = nn.Conv2d(channels, channels, 1)
        self.out_proj = nn.Conv2d(channels, channels, 1)
        
        # 权重初始化
        for proj in [self.q_proj, self.k_proj, self.v_proj]:
            nn.init.kaiming_normal_(proj.weight, mode='fan_out', nonlinearity='relu')
        nn.init.zeros_(self.out_proj.weight)
        
        self._initialized = True

    def forward(self, x):
        # 自动处理多种输入格式
        if isinstance(x, torch.Tensor):
            ir, vis = x.chunk(2, dim=1)
        elif isinstance(x, (list, tuple)):
            ir, vis = x[0], x[1]
        else:
            raise ValueError("输入应为张量或[ir,vis]列表")
            
        # 首次运行时初始化
        if not self._initialized:
            self._initialize_params(ir.size(1))
            self.to(ir.device)  # 确保层在正确设备上
            
        B, C, H, W = ir.shape
        
        # 投影并拆分为多头
        q = self.q_proj(ir).view(B, self.num_heads, self.head_dim, H*W)
        k = self.k_proj(vis).view(B, self.num_heads, self.head_dim, H*W)
        v = self.v_proj(vis).view(B, self.num_heads, self.head_dim, H*W)
        
        # 注意力计算
        attn = torch.einsum('bhdk,bhek->bhde', q, k) * self.scale
        attn = F.softmax(attn, dim=-1)
        out = torch.einsum('bhde,bhek->bhdk', attn, v)
        
        # 合并输出
        out = out.contiguous().view(B, C, H, W)
        return self.out_proj(out)