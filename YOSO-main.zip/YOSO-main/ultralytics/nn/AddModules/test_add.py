import torch.nn as nn
class tad(nn.Module):
    def __init__(self,channel):
        self.channel = channel
    def forward(self, x):
        x1 = x[0]
        x2 = x[1]
        return x1+x2

