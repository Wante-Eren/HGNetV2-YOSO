import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from einops import rearrange
try:
    from causal_conv1d import causal_conv1d_fn
except ImportError:
    causal_conv1d_fn = None

try:
    from mamba_ssm.ops.triton.layernorm_gated import RMSNorm as RMSNormGated, LayerNorm
except ImportError:
    RMSNormGated, LayerNorm = None, None

from mamba_ssm.ops.triton.ssd_combined import mamba_chunk_scan_combined
from mamba_ssm.ops.triton.ssd_combined import mamba_split_conv1d_scan_combined
class HaarWavelet(nn.Module):
    """修复版Haar小波变换"""

    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels

        # 更安全的权重初始化
        weights = torch.tensor([
            [1, 1, 1, 1],
            [1, -1, 1, -1],
            [1, 1, -1, -1],
            [1, -1, -1, 1]
        ], dtype=torch.float32)

        # 关键修复：调整权重形状为[4*in_channels, 1, 2, 2]
        weights = weights.view(4, 1, 2, 2)
        weights = weights.repeat(in_channels, 1, 1, 1)  # [4*in_channels, 1, 2, 2]
        self.register_buffer('weights', weights)
        self.groups = in_channels  # 分组数等于输入通道数

    def forward(self, x, rev=False):
        if not rev:
            # 正向变换
            B, C, H, W = x.shape
            pad_h, pad_w = (2 - H % 2) % 2, (2 - W % 2) % 2
            if pad_h or pad_w:
                x = F.pad(x, (0, pad_w, 0, pad_h))
            # 输出通道数变为4*C
            return F.conv2d(x, self.weights, stride=2, groups=self.groups) / 2.0
        else:
            # 逆向变换
            return F.conv_transpose2d(x, self.weights, stride=2, groups=self.groups)


class WaveletProcessor(nn.Module):
    """轻量级小波处理器"""

    def __init__(self, in_channels, wavelet_type='haar'):
        super().__init__()
        self.in_channels = in_channels
        self.wavelet = HaarWavelet(in_channels)

        # 限制最大通道数防止显存爆炸
        max_channels = min(4 * in_channels, 1024)
        self.process = nn.Sequential(
            nn.Conv2d(4 * in_channels, max_channels, 1, groups=4),
            nn.ReLU(),
            nn.Conv2d(max_channels, 4 * in_channels, 1, groups=4)
        )
        # 移除recon层，因为重构后通道数自动匹配

    def forward(self, x):
        orig_size = x.shape[2:]

        # 小波分解
        decomposed = self.wavelet(x, rev=False)  # 输出[B, 4*C, H/2, W/2]

        # 特征处理
        processed = self.process(decomposed)  # 输出[B, 4*C, H/2, W/2]

        # 小波重构
        reconstructed = self.wavelet(processed, rev=True)  # 输出[B, C, H, W]

        # 尺寸对齐
        if reconstructed.shape[2:] != orig_size:
            reconstructed = reconstructed[:, :, :orig_size[0], :orig_size[1]]

        return x + reconstructed


class EfficientCrossAttention(nn.Module):
    """显存高效的交叉注意力"""

    def __init__(self, channels, num_heads=4):
        super().__init__()
        self.num_heads = min(num_heads, channels)
        self.head_dim = max(1, channels // self.num_heads)
        self.scale = self.head_dim ** -0.5 if self.head_dim > 0 else 1.0

        self.q_proj = nn.Conv2d(channels, channels, 1)
        self.k_proj = nn.Conv2d(channels, channels, 1)
        self.v_proj = nn.Conv2d(channels, channels, 1)
        self.out_proj = nn.Conv2d(channels, channels, 1)

    def forward(self, ir, vis):
        B, C, H, W = ir.size()

        # 投影
        q = self.q_proj(ir).view(B, self.num_heads, self.head_dim, H * W)
        k = self.k_proj(vis).view(B, self.num_heads, self.head_dim, H * W)
        v = self.v_proj(vis).view(B, self.num_heads, self.head_dim, H * W)

        # 注意力计算
        attn = torch.einsum('bhdk,bhek->bhde', q, k) * self.scale
        attn = F.softmax(attn, dim=-1)
        out = torch.einsum('bhde,bhek->bhdk', attn, v)

        # 合并多头
        out = out.permute(0, 2, 1, 3).contiguous().view(B, C, H, W)
        return self.out_proj(out)


class GlobalContextBranch(nn.Module):
    """全局上下文分支"""

    def __init__(self, channels):
        super().__init__()
        self.cross_attn = EfficientCrossAttention(channels)
        self.min_channels = max(4, channels // 8)

        # 共享基础卷积
        self.base_conv = nn.Conv2d(channels, self.min_channels, 3, padding=1)

        # 多尺度卷积
        self.dilated_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(self.min_channels, self.min_channels, 3,
                          padding=d, dilation=d, groups=self.min_channels),
                nn.BatchNorm2d(self.min_channels),
                nn.ReLU()
            ) for d in [1, 2, 4]
        ])

        # 特征增强
        self.enhance = nn.Sequential(
            nn.Conv2d(channels + 3 * self.min_channels, channels, 1),
            nn.InstanceNorm2d(channels),
            nn.GELU()
        )

    def forward(self, ir, vis):
        # 交叉注意力融合
        fused = self.cross_attn(ir, vis)

        # 多尺度特征提取
        x = self.base_conv(fused)
        features = [conv(x) for conv in self.dilated_convs]
        multi_scale = torch.cat(features, dim=1)

        # 残差增强
        combined = torch.cat([fused, multi_scale], dim=1)
        return fused + self.enhance(combined)


class SE_Block(nn.Module):
    """压缩-激励注意力"""

    def __init__(self, inchannel, ratio=16):
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(inchannel, max(1, inchannel // ratio)),
            nn.ReLU(),
            nn.Linear(max(1, inchannel // ratio), inchannel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c = x.shape[:2]
        y = self.gap(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y

class NCMamba2(nn.Module):
    def __init__(
            self,
            d_model,
            d_state=64,
            headdim=64,  # default to 64

            d_conv=3,  # default to 3 for 2D
            conv_init=None,
            expand=2,
            ngroups=1,
            A_init_range=(1, 16),
            dt_min=0.001,
            dt_max=0.1,
            dt_init_floor=1e-4,
            dt_limit=(0.0, float("inf")),
            learnable_init_states=False,
            activation="silu",  # default to silu
            bias=False,
            conv_bias=True,
            # Fused kernel and sharding options
            chunk_size=256,
            use_mem_eff_path=False,  # default to False, for custom implementation
            layer_idx=None,  # Absorb kwarg for general module
            device=None,
            dtype=None,
            linear_attn_duality=True,
            **kwargs
    ):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.d_model = d_model
        self.d_conv = d_conv
        self.conv_init = conv_init
        self.expand = expand
        self.d_inner = int(self.expand * self.d_model)
        self.headdim = headdim
        self.d_state = d_state
        if ngroups == -1:
            ngroups = self.d_inner // self.headdim  # equivalent to multi-head attention
        self.ngroups = ngroups
        assert self.d_inner % self.headdim == 0
        self.nheads = self.d_inner // self.headdim
        self.dt_limit = dt_limit
        self.learnable_init_states = learnable_init_states
        self.activation = activation
        # convert chunk_size to triton.language.int32
        self.chunk_size = chunk_size  # torch.tensor(chunk_size,dtype=torch.int32)
        self.use_mem_eff_path = use_mem_eff_path
        self.layer_idx = layer_idx
        self.ssd_positve_dA = kwargs.get('ssd_positve_dA', True)  # default to False, ablation for linear attn duality
        # Order: [z, x, B, C, dt]
        d_in_proj = 2 * self.d_inner + 2 * self.ngroups * self.d_state + self.nheads
        self.in_proj = nn.Linear(self.d_model, int(d_in_proj), bias=bias, **factory_kwargs)  #

        conv_dim = self.d_inner + 2 * self.ngroups * self.d_state

        self.conv2d = nn.Conv2d(
            in_channels=conv_dim,
            out_channels=conv_dim,
            groups=conv_dim,
            bias=conv_bias,
            kernel_size=d_conv,
            padding=(d_conv - 1) // 2,
            **factory_kwargs,
        )
        if self.conv_init is not None:
            nn.init.uniform_(self.conv1d.weight, -self.conv_init, self.conv_init)
        # self.conv1d.weight._no_weight_decay = True

        if self.learnable_init_states:
            self.init_states = nn.Parameter(torch.zeros(self.nheads, self.headdim, self.d_state, **factory_kwargs))
            self.init_states._no_weight_decay = True

        self.act = nn.SiLU()

        # Initialize log dt bias
        dt = torch.exp(
            torch.rand(self.nheads, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min)
        )
        dt = torch.clamp(dt, min=dt_init_floor)
        # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
        inv_dt = dt + torch.log(-torch.expm1(-dt))
        self.dt_bias = nn.Parameter(inv_dt)
        # Just to be explicit. Without this we already don't put wd on dt_bias because of the check
        # name.endswith("bias") in param_grouping.py
        self.dt_bias._no_weight_decay = True

        # A parameter
        assert A_init_range[0] > 0 and A_init_range[1] >= A_init_range[0]
        A = torch.empty(self.nheads, dtype=torch.float32, device=device).uniform_(*A_init_range)
        A_log = torch.log(A).to(dtype=dtype)
        self.A_log = nn.Parameter(A_log)
        # self.register_buffer("A_log", torch.zeros(self.nheads, dtype=torch.float32, device=device), persistent=True)
        self.A_log._no_weight_decay = True

        # D "skip" parameter
        self.D = nn.Parameter(torch.ones(self.nheads, device=device))
        self.D._no_weight_decay = True

        # modified from RMSNormGated to layer norm
        # assert RMSNormGated is not None
        # self.norm = RMSNormGated(self.d_inner, eps=1e-5, norm_before_gate=False, **factory_kwargs)
        self.norm1 = nn.LayerNorm(self.d_model)
        self.norm2 = nn.LayerNorm(self.d_inner)
        self.out_proj = nn.Linear(self.d_inner, self.d_model, bias=bias, **factory_kwargs)

        # linear attention duality
        self.linear_attn_duality = linear_attn_duality
        self.kwargs = kwargs

    def non_casual_linear_attn(self, x, dt, A, B, C, D, H=None, W=None):
        '''
        non-casual attention duality of mamba v2
        x: (B, L, nheads, head_dim), equivalent to V in attention
        dt: (B, L, nheads)
        A: (nheads) or (d_inner, d_state)
        B: (B, L, d_state), equivalent to K in attention
        C: (B, L, d_state), equivalent to Q in attention
        D: (nheads), equivalent to the skip connection
        '''

        batch, seqlen, head, dim = x.shape
        dstate = B.shape[2]
        V = x.permute(0, 2, 1, 3).contiguous()  # (B, nheads, L, head_dim)
        dt = dt.permute(0, 2, 1).contiguous()  # (B, nheads, L)
        dA = dt.unsqueeze(-1) * A.view(1, -1, 1, 1).repeat(batch, 1, seqlen, 1).contiguous()  # (B, nheads, L, 1)
        if self.ssd_positve_dA: dA = -dA

        V_scaled = V * dA  # (B, H, L, head_dim)
        K = B.view(batch, 1, seqlen, dstate)  # (B, 1, L, d_state)
        if getattr(self, "__DEBUG__", False):
            A_mat = dA.cpu().detach().numpy()
            A_mat = A_mat.reshape(batch, -1, H, W)
            setattr(self, "__data__", dict(
                dA=A_mat, H=H, W=W, V=V, ))

        if self.ngroups == 1:
            ## get kv via transpose K and V
            KV = K.transpose(-2, -1).contiguous() @ V_scaled  # (B, num_head, d_state, D)
            Q = C.view(batch, 1, seqlen, dstate)  # .repeat(1, head, 1, 1) (B, 1, L, d_state)
            x = Q @ KV  # (B, num_head, L, D)
            x = x + V * D.view(1, -1, 1, 1).repeat(batch, 1, seqlen, 1).contiguous()

            # V = V.reshape(batch*head, H, W, -1).permute(0, 3, 1, 2) #(B*num_head, D, H, W)
            # x = x + self.dwc(V).reshape(batch, head, -1, H*W).permute(0, 1, 3, 2)

            x = x.permute(0, 2, 1, 3).contiguous()  # (B, L, H, D)
        else:
            assert head % self.ngroups == 0
            dstate = dstate // self.ngroups
            K = K.view(batch, 1, seqlen, self.ngroups, dstate).permute(0, 1, 3, 2, 4)  # (B, 1, g, L, dstate)
            V_scaled = V_scaled.view(batch, head // self.ngroups, self.ngroups, seqlen, dim)  # (B, H//g, g, L, D)
            Q = C.view(batch, 1, seqlen, self.ngroups, dstate).permute(0, 1, 3, 2, 4)  # (B, 1, g, L, dstate)

            KV = K.transpose(-2, -1) @ V_scaled  # (B, H//g, g, dstate, D)
            x = Q @ KV  # (B, H//g, g, L, D)
            V_skip = (V * D.view(1, -1, 1, 1).repeat(batch, 1, seqlen, 1)).view(batch, head // self.ngroups,
                                                                                self.ngroups, seqlen,
                                                                                dim)  # (B, H//g, g, L, D)
            x = x + V_skip  # (B, H//g, g, L, D)
            x = x.permute(0, 3, 1, 2, 4).flatten(2, 3).reshape(batch, seqlen, head, dim)  # (B, L, H, D)
            x = x.contiguous()

        return x

    def forward(self, inputs, seq_idx=None):
        """
        inputs: (B, C, H, W)
        u: (B, H*W, C)
        Returns: same shape as inputs
        """
        # print("inputs type:", inputs.type())
        B, C, H, W = inputs.shape
        inputs_og = inputs
        u = inputs.reshape(B, C, H * W).transpose(1, 2).contiguous()
        batch, seqlen, dim = u.shape

        zxbcdt = self.in_proj(u)  # (B, L, d_in_proj)
        A = -torch.exp(self.A_log)  # (nheads) or (d_inner, d_state)
        initial_states = repeat(self.init_states, "... -> b ...",
                                b=batch).contiguous() if self.learnable_init_states else None
        dt_limit_kwargs = {} if self.dt_limit == (0.0, float("inf")) else dict(dt_limit=self.dt_limit)

        z, xBC, dt = torch.split(
            zxbcdt, [self.d_inner, self.d_inner + 2 * self.ngroups * self.d_state, self.nheads], dim=-1
        )
        dt = F.softplus(dt + self.dt_bias)  # (B, L, nheads)
        assert self.activation in ["silu", "swish"]

        # 2D Convolution
        xBC = xBC.view(batch, H, W, -1).permute(0, 3, 1, 2).contiguous()
        xBC = self.act(self.conv2d(xBC))
        xBC = xBC.permute(0, 2, 3, 1).view(batch, H * W, -1).contiguous()

        # Split into 3 main branches: X, B, C
        # These correspond to V, K, Q respectively in the SSM/attention duality
        x, B, C = torch.split(xBC, [self.d_inner, self.ngroups * self.d_state, self.ngroups * self.d_state], dim=-1)

        # x, dt, A, B, C = to_ttensor(x, dt, A, B, C)

        if self.linear_attn_duality:
            y = self.non_casual_linear_attn(
                rearrange(x, "b l (h p) -> b l h p", p=self.headdim),
                dt, A, B, C, self.D, H, W
            )
        else:
            if self.kwargs.get('bidirection', False):
                # assert self.ngroups == 2 #only support bidirectional with 2 groups
                x = to_ttensor(rearrange(x, "b l (h p) -> b l h p", p=self.headdim)).chunk(2, dim=-2)
                B = to_ttensor(rearrange(B, "b l (g n) -> b l g n", g=self.ngroups)).chunk(2, dim=-2)
                C = to_ttensor(rearrange(C, "b l (g n) -> b l g n", g=self.ngroups)).chunk(2, dim=-2)
                dt = dt.chunk(2, dim=-1)  # (B, L, nheads) -> (B, L, nheads//2)*2
                A, D = A.chunk(2, dim=-1), self.D.chunk(2, dim=-1)  # (nheads) -> (nheads//2)*2
                y_forward = mamba_chunk_scan_combined(
                    x[0], dt[0], A[0], B[0], C[0], chunk_size=self.chunk_size, D=D[0], z=None, seq_idx=seq_idx,
                    initial_states=initial_states, **dt_limit_kwargs
                )
                y_backward = mamba_chunk_scan_combined(
                    x[1].flip(1), dt[1].flip(1), A[1], B[1].flip(1), C[1].flip(1), chunk_size=self.chunk_size, D=D[1],
                    z=None, seq_idx=seq_idx,
                    initial_states=initial_states, **dt_limit_kwargs
                )
                y = torch.cat([y_forward, y_backward.flip(1)], dim=-2)
            else:
                y = mamba_chunk_scan_combined(
                    to_ttensor(rearrange(x, "b l (h p) -> b l h p", p=self.headdim)),
                    to_ttensor(dt),
                    to_ttensor(A),
                    to_ttensor(rearrange(B, "b l (g n) -> b l g n", g=self.ngroups)),
                    to_ttensor(rearrange(C, "b l (g n) -> b l g n", g=self.ngroups)),
                    chunk_size=self.chunk_size,
                    D=to_ttensor(self.D),
                    z=None,
                    seq_idx=seq_idx,
                    initial_states=initial_states,
                    **dt_limit_kwargs,
                )
        y = rearrange(y, "b l h p -> b l (h p)")

        y = self.norm2(y)

        y = y * z
        out = self.out_proj(y)

        out = out.transpose(1, 2).contiguous().reshape(out.shape[0], out.shape[2], H, W)
        return out
class WGCAVSSD(nn.Module):
    """完整的多模态融合网络"""

    def __init__(self, channels, d_st, hdim):
        super().__init__()
        # 确保channels是整数
        if isinstance(channels, list):
            channels = channels[0]  # 取列表中的第一个元素作为通道数
        elif isinstance(channels, tuple):
            channels = channels[0]

        assert isinstance(channels, int), f"通道数应为整数, 实际类型为{type(channels)}"
        assert channels >= 4, f"通道数不能小于4, 当前为{channels}"

        self.channels = channels

        # 模态处理器
        self.ir_processor = WaveletProcessor(channels)
        self.vis_processor = WaveletProcessor(channels)

        # 特征融合分支
        self.global_branch = GlobalContextBranch(channels)
        self.se_block = SE_Block(channels)

        # 自适应融合
        self.gamma = nn.Parameter(torch.tensor(0.5))

        # Mamba模块
        self.vssd = NCMamba2(
            d_model = channels,
            d_state = d_st,
            headdim = hdim
        )

    def forward(self, inputs):
        """支持多种输入格式：
        - List/Tuple: [ir_tensor, vis_tensor]
        - Dict: {'ir': ir_tensor, 'vis': vis_tensor}
        """
        if isinstance(inputs, (list, tuple)):
            ir, vis = inputs
        elif isinstance(inputs, dict):
            ir, vis = inputs['ir'], inputs['vis']
        else:
            raise ValueError("输入应为[ir,vis]或{'ir':tensor,'vis':tensor}")

        # 尺寸验证
        assert ir.shape == vis.shape, f"输入尺寸不匹配: IR {ir.shape} != VIS {vis.shape}"

        # 模态处理
        ir_feat = self.ir_processor(ir)
        vis_feat = self.vis_processor(vis)

        # 小波分支
        wavelet = ir_feat + vis_feat
        wavelet_out = self.se_block(wavelet)

        # 全局分支
        global_out = self.global_branch(ir_feat, vis_feat)

        # 动态融合
        blended = self.gamma * wavelet_out + (1 - self.gamma) * global_out

        # Mamba特征增强
        return self.vssd(blended)
        """
 .task:
elif m is WGCAVSSD:
    c1 = [ch[x] for x in f]
    c2 = c1[0]
    args = [c2, *args]

        """