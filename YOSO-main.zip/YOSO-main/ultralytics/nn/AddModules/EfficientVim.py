import math
import torch
import torch.nn as nn
 
from ultralytics.nn.modules.block import Bottleneck, C2f,C3k,C3k2
from ultralytics.nn.modules.conv import Conv
 
__all__ = ['EfficientViMBlock']
 
######################  MSCAAttention ####     START   by  AI&CV  ###############################
 
 
from torch.nn import functional as F
 
 
 
class MSCAAttention(nn.Module):
    # SegNext NeurIPS 2022
    # https://github.com/Visual-Attention-Network/SegNeXt/tree/main
    def __init__(self, dim):
        super().__init__()
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        self.conv0_1 = nn.Conv2d(dim, dim, (1, 7), padding=(0, 3), groups=dim)
        self.conv0_2 = nn.Conv2d(dim, dim, (7, 1), padding=(3, 0), groups=dim)
 
        self.conv1_1 = nn.Conv2d(dim, dim, (1, 11), padding=(0, 5), groups=dim)
        self.conv1_2 = nn.Conv2d(dim, dim, (11, 1), padding=(5, 0), groups=dim)
 
        self.conv2_1 = nn.Conv2d(dim, dim, (1, 21), padding=(0, 10), groups=dim)
        self.conv2_2 = nn.Conv2d(dim, dim, (21, 1), padding=(10, 0), groups=dim)
        self.conv3 = nn.Conv2d(dim, dim, 1)
 
    def forward(self, x):
        u = x.clone()
        attn = self.conv0(x)
 
        attn_0 = self.conv0_1(attn)
        attn_0 = self.conv0_2(attn_0)
 
        attn_1 = self.conv1_1(attn)
        attn_1 = self.conv1_2(attn_1)
 
        attn_2 = self.conv2_1(attn)
        attn_2 = self.conv2_2(attn_2)
        attn = attn + attn_0 + attn_1 + attn_2
 
        attn = self.conv3(attn)
 
        return attn * u
 
 
###################### MSCAAttention  ####     end   by  AI&CV  ###############################
 
 
class LayerNorm2D(nn.Module):
    """LayerNorm for channels of 2D tensor(B C H W)"""
 
    def __init__(self, num_channels, eps=1e-5, affine=True):
        super(LayerNorm2D, self).__init__()
        self.num_channels = num_channels
        self.eps = eps
        self.affine = affine
 
        if self.affine:
            self.weight = nn.Parameter(torch.ones(1, num_channels, 1, 1))
            self.bias = nn.Parameter(torch.zeros(1, num_channels, 1, 1))
        else:
            self.register_parameter('weight', None)
            self.register_parameter('bias', None)
 
    def forward(self, x):
        mean = x.mean(dim=1, keepdim=True)  # (B, 1, H, W)
        var = x.var(dim=1, keepdim=True, unbiased=False)  # (B, 1, H, W)
 
        x_normalized = (x - mean) / torch.sqrt(var + self.eps)  # (B, C, H, W)
 
        if self.affine:
            x_normalized = x_normalized * self.weight + self.bias
 
        return x_normalized
 
 
class LayerNorm1D(nn.Module):
    """LayerNorm for channels of 1D tensor(B C L)"""
 
    def __init__(self, num_channels, eps=1e-5, affine=True):
        super(LayerNorm1D, self).__init__()
        self.num_channels = num_channels
        self.eps = eps
        self.affine = affine
 
        if self.affine:
            self.weight = nn.Parameter(torch.ones(1, num_channels, 1))
            self.bias = nn.Parameter(torch.zeros(1, num_channels, 1))
        else:
            self.register_parameter('weight', None)
            self.register_parameter('bias', None)
 
    def forward(self, x):
        mean = x.mean(dim=1, keepdim=True)  # (B, 1, H, W)
        var = x.var(dim=1, keepdim=True, unbiased=False)  # (B, 1, H, W)
 
        x_normalized = (x - mean) / torch.sqrt(var + self.eps)  # (B, C, H, W)
 
        if self.affine:
            x_normalized = x_normalized * self.weight + self.bias
 
        return x_normalized
 
 
class ConvLayer2D(nn.Module):
    def __init__(self, in_dim, out_dim, kernel_size=3, stride=1, padding=0, dilation=1, groups=1, norm=nn.BatchNorm2d,
                 act_layer=nn.ReLU, bn_weight_init=1):
        super(ConvLayer2D, self).__init__()
        self.conv = nn.Conv2d(
            in_dim,
            out_dim,
            kernel_size=(kernel_size, kernel_size),
            stride=(stride, stride),
            padding=(padding, padding),
            dilation=(dilation, dilation),
            groups=groups,
            bias=False
        )
        self.norm = norm(num_features=out_dim) if norm else None
        self.act = act_layer() if act_layer else None
 
        if self.norm:
            torch.nn.init.constant_(self.norm.weight, bn_weight_init)
            torch.nn.init.constant_(self.norm.bias, 0)
 
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv(x)
        if self.norm:
            x = self.norm(x)
        if self.act:
            x = self.act(x)
        return x
 
 
class ConvLayer1D(nn.Module):
    def __init__(self, in_dim, out_dim, kernel_size=3, stride=1, padding=0, dilation=1, groups=1, norm=nn.BatchNorm1d,
                 act_layer=nn.ReLU, bn_weight_init=1):
        super(ConvLayer1D, self).__init__()
        self.conv = nn.Conv1d(
            in_dim,
            out_dim,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
            bias=False
        )
        self.norm = norm(num_features=out_dim) if norm else None
        self.act = act_layer() if act_layer else None
 
        if self.norm:
            torch.nn.init.constant_(self.norm.weight, bn_weight_init)
            torch.nn.init.constant_(self.norm.bias, 0)
 
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv(x)
        if self.norm:
            x = self.norm(x)
        if self.act:
            x = self.act(x)
        return x
 
 
class FFN(nn.Module):
    def __init__(self, in_dim, dim):
        super().__init__()
        self.fc1 = ConvLayer2D(in_dim, dim, 1)
        self.fc2 = ConvLayer2D(dim, in_dim, 1, act_layer=None, bn_weight_init=0)
 
    def forward(self, x):
        x = self.fc2(self.fc1(x))
        return x
 
 
class HSMSSD(nn.Module):
    def __init__(self, d_model, ssd_expand=1, A_init_range=(1, 16), state_dim=64):
        super().__init__()
        self.ssd_expand = ssd_expand
        self.d_inner = int(self.ssd_expand * d_model)
        self.state_dim = state_dim

        self.BCdt_proj = ConvLayer1D(d_model, 3 * state_dim, 1, norm=None, act_layer=None)
        conv_dim = self.state_dim * 3
        self.dw = ConvLayer2D(conv_dim, conv_dim, 3, 1, 1, groups=conv_dim, norm=None, act_layer=None, bn_weight_init=0)
        self.hz_proj = ConvLayer1D(d_model, 2 * self.d_inner, 1, norm=None, act_layer=None)
        self.out_proj = ConvLayer1D(self.d_inner, d_model, 1, norm=None, act_layer=None, bn_weight_init=0)

        A = torch.empty(self.state_dim, dtype=torch.float32).uniform_(*A_init_range)
        self.A = torch.nn.Parameter(A)
        self.act = nn.SiLU()
        self.D = nn.Parameter(torch.ones(1))
        self.D._no_weight_decay = True

    def forward(self, x, size):
        batch, _, L = x.shape
        
        # 1. BCdt计算（确保不原地操作）
        BCdt = self.BCdt_proj(x)  # [B, 3*state_dim, L]
        BCdt = BCdt.view(batch, -1, size[0], size[1])  # [B, C, H, W]
        BCdt = self.dw(BCdt)  # 深度卷积
        BCdt = BCdt.flatten(2)  # [B, C, H*W]
        
        # 2. 安全分割（使用clone分离视图）
        B, C, dt = [t.clone() for t in torch.split(BCdt, self.state_dim, dim=1)]
        
        # 3. 状态空间计算
        A = (dt + self.A.view(1, -1, 1)).softmax(-1)
        AB = A * B
        h = x @ AB.transpose(-2, -1)
        
        # 4. 门控计算（显式非原地操作）
        hz = self.hz_proj(h)
        h, z = [t.clone() for t in torch.split(hz, self.d_inner, dim=1)]
        gate = self.act(z)  # 非原地激活
        out = h * gate + h * self.D  # 所有操作都是非原地的
        out = self.out_proj(out)
        
        # 5. 输出计算
        y = out @ C
        return y.view(batch, -1, size[0], size[1]), h
 
class ConvolutionalGLU(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.) -> None:
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        hidden_features = int(2 * hidden_features / 3)
        self.fc1 = nn.Conv2d(in_features, hidden_features * 2, 1)
        self.dwconv = nn.Sequential(
            nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1, bias=True,
                      groups=hidden_features),
            act_layer()
        )
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1)
        self.drop = nn.Dropout(drop)
 
    # def forward(self, x):
    #     x, v = self.fc1(x).chunk(2, dim=1)
    #     x = self.dwconv(x) * v
    #     x = self.drop(x)
    #     x = self.fc2(x)
    #     x = self.drop(x)
    #     return x
 
    def forward(self, x):
        x_shortcut = x
        x, v = self.fc1(x).chunk(2, dim=1)
        x = self.dwconv(x) * v
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x_shortcut + x
 
 
 
class EfficientViMBlock_att(nn.Module):
    def __init__(self, dim, mlp_ratio=4., ssd_expand=1, state_dim=64):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
 
        self.mixer = HSMSSD(d_model=dim, ssd_expand=ssd_expand, state_dim=state_dim)
        self.norm = LayerNorm1D(dim)
 
        self.dwconv1 = ConvLayer2D(dim, dim, 3, padding=1, groups=dim, bn_weight_init=0, act_layer=None)
        self.dwconv2 = ConvLayer2D(dim, dim, 3, padding=1, groups=dim, bn_weight_init=0, act_layer=None)
 
        self.ffn = FFN(in_dim=dim, dim=int(dim * mlp_ratio))
        self.att = MSCAAttention(dim)
 
        # LayerScale
        self.alpha = nn.Parameter(1e-4 * torch.ones(4, dim), requires_grad=True)
 
    def forward(self, x):
        alpha = torch.sigmoid(self.alpha).view(4, -1, 1, 1)
 
        # DWconv1
        x = (1 - alpha[0]) * x + alpha[0] * self.dwconv1(x)
 
        # HSM-SSD
        x_prev = x
        _, _, H, W = x.size()
        x, h = self.mixer(self.norm(x.flatten(2)), (H, W))
        x = (1 - alpha[1]) * x_prev + alpha[1] * x
 
        # DWConv2
        x = (1 - alpha[2]) * x + alpha[2] * self.dwconv2(x)
 
        # FFN
        x = (1 - alpha[3]) * x + alpha[3] * self.ffn(x)
        x=  self.att(x)
 
        return x
 
class EfficientViMBlock(nn.Module):
    def __init__(self, dim, mlp_ratio=4., ssd_expand=1, state_dim=64):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
 
        self.mixer = HSMSSD(d_model=dim, ssd_expand=ssd_expand, state_dim=state_dim)
        self.norm = LayerNorm1D(dim)
 
        self.dwconv1 = ConvLayer2D(dim, dim, 3, padding=1, groups=dim, bn_weight_init=0, act_layer=None)
        self.dwconv2 = ConvLayer2D(dim, dim, 3, padding=1, groups=dim, bn_weight_init=0, act_layer=None)
 
        self.ffn = FFN(in_dim=dim, dim=int(dim * mlp_ratio))
 
        # LayerScale
        self.alpha = nn.Parameter(1e-4 * torch.ones(4, dim), requires_grad=True)
 
    def forward(self, x):
        alpha = torch.sigmoid(self.alpha).view(4, -1, 1, 1)
 
        # DWconv1
        x = (1 - alpha[0]) * x + alpha[0] * self.dwconv1(x)
 
        # HSM-SSD
        x_prev = x
        _, _, H, W = x.size()
        x, h = self.mixer(self.norm(x.flatten(2)), (H, W))
        x = (1 - alpha[1]) * x_prev + alpha[1] * x
 
        # DWConv2
        x = (1 - alpha[2]) * x + alpha[2] * self.dwconv2(x)
 
        # FFN
        x = (1 - alpha[3]) * x + alpha[3] * self.ffn(x)
        return x
 
 
class C2f_EfficientVIM_att(C2f):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        self.m = nn.ModuleList(EfficientViMBlock_att(self.c) for _ in range(n))
 
 
class C3k_EfficientVIM_att(C3k):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=3):
        super().__init__(c1, c2, n, shortcut, g, e, k)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(EfficientViMBlock_att(c_) for _ in range(n)))
 
 
class C3k2_EfficientVIM_att(C3k2):
    def __init__(self, c1, c2, n=1, c3k=False, e=0.5, g=1, shortcut=True):
        super().__init__(c1, c2, n, c3k, e, g, shortcut)
        self.m = nn.ModuleList(
            C3k_EfficientVIM_att(self.c, self.c, 2, shortcut, g) if c3k else EfficientViMBlock_att(self.c) for _ in range(n))
 
class C2f_EfficientVIM(C2f):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        self.m = nn.ModuleList(EfficientViMBlock(self.c) for _ in range(n))
 
 
class C3k_EfficientVIM(C3k):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=3):
        super().__init__(c1, c2, n, shortcut, g, e, k)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(EfficientViMBlock(c_) for _ in range(n)))
 
 
class C3k2_EfficientVIM(C3k2):
    def __init__(self, c1, c2, n=1, c3k=False, e=0.5, g=1, shortcut=True):
        super().__init__(c1, c2, n, c3k, e, g, shortcut)
        self.m = nn.ModuleList(
            C3k_EfficientVIM(self.c, self.c, 2, shortcut, g) if c3k else EfficientViMBlock(self.c) for _ in range(n))