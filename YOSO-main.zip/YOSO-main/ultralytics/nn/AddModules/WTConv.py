import pywt
import pywt.data
import torch
from torch import nn
from functools import partial
import torch.nn.functional as F


# 关键：自行实现YOLO的make_divisible函数（确保通道数为8的倍数）
def make_divisible(x, divisor=8, min_value=None):
    """
    将x调整为最接近的divisor的倍数（默认8）
    参考YOLO官方实现：https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/torch_utils.py
    """
    if min_value is None:
        min_value = divisor
    new_x = max(min_value, int(x + divisor / 2) // divisor * divisor)
    # 确保向下调整不超过10%
    if new_x < 0.9 * x:
        new_x += divisor
    return new_x


def create_wavelet_filter(wave, in_size, out_size, type=torch.float):
    if not isinstance(wave, str):
        raise TypeError(f"小波类型必须是字符串（如'haar'、'bior2.2'），但传入了{type(wave)}类型的值：{wave}")
    
    try:
        w = pywt.Wavelet(wave)
    except ValueError as e:
        common_wavelets = ['haar', 'db1', 'bior2.2', 'bior3.3', 'bior4.4']
        raise ValueError(
            f"无效的小波类型：{wave}。常见有效的小波类型包括：{common_wavelets}\n"
            f"详细错误：{str(e)}"
        ) from e

    dec_hi = torch.tensor(w.dec_hi[::-1], dtype=type)
    dec_lo = torch.tensor(w.dec_lo[::-1], dtype=type)
    dec_filters = torch.stack([dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)], dim=0)
    dec_filters = dec_filters[:, None].repeat(in_size, 1, 1, 1)

    rec_hi = torch.tensor(w.rec_hi[::-1], dtype=type).flip(dims=[0])
    rec_lo = torch.tensor(w.rec_lo[::-1], dtype=type).flip(dims=[0])
    rec_filters = torch.stack([rec_lo.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_lo.unsqueeze(0) * rec_hi.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_hi.unsqueeze(1)], dim=0)
    rec_filters = rec_filters[:, None].repeat(out_size, 1, 1, 1)

    return dec_filters, rec_filters


def wavelet_transform(x, filters):
    b, c, h, w = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = F.conv2d(x, filters, stride=2, groups=c, padding=pad)
    x = x.reshape(b, c, 4, h // 2, w // 2)
    return x


def inverse_wavelet_transform(x, filters):
    b, c, _, h_half, w_half = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = x.reshape(b, c * 4, h_half, w_half)
    x = F.conv_transpose2d(x, filters, stride=2, groups=c, padding=pad)
    return x


class WTConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=5, stride=1, bias=True, 
                 wt_levels=1, wt_type='db1'):
        super(WTConv2d, self).__init__()
        # 1. 适配YOLO通道缩放：使用自定义的make_divisible确保通道是8的倍数
        self.in_channels = make_divisible(in_channels, 8)
        self.out_channels = self.in_channels  # WTConv2d要求输入输出通道一致
        assert self.in_channels == self.out_channels, "WTConv2d输入输出通道必须相同"

        self.wt_levels = wt_levels
        self.stride = stride
        self.dilation = 1

        # 2. 小波滤波器：使用调整后的通道数
        self.wt_filter, self.iwt_filter = create_wavelet_filter(
            wt_type, self.in_channels, self.out_channels, torch.float
        )
        self.wt_filter = nn.Parameter(self.wt_filter, requires_grad=False)
        self.iwt_filter = nn.Parameter(self.iwt_filter, requires_grad=False)

        self.wt_function = partial(wavelet_transform, filters=self.wt_filter)
        self.iwt_function = partial(inverse_wavelet_transform, filters=self.iwt_filter)

        # 3. 基础卷积层：使用调整后的通道数
        self.base_conv = nn.Conv2d(
            self.in_channels, self.out_channels, kernel_size,
            padding='same', stride=1, dilation=1, groups=self.in_channels, bias=bias
        )
        self.base_scale = _ScaleModule([1, self.in_channels, 1, 1])

        # 4. 小波卷积层：通道数 = 调整后通道数 * 4（适配4个小波分支）
        self.wavelet_convs = nn.ModuleList(
            [nn.Conv2d(
                self.in_channels * 4, self.in_channels * 4, kernel_size,
                padding='same', stride=1, dilation=1, groups=self.in_channels * 4, bias=False
            ) for _ in range(self.wt_levels)]
        )
        self.wavelet_scale = nn.ModuleList(
            [_ScaleModule([1, self.in_channels * 4, 1, 1], init_scale=0.1) 
             for _ in range(self.wt_levels)]
        )

        if self.stride > 1:
            self.stride_filter = nn.Parameter(torch.ones(self.in_channels, 1, 1, 1), requires_grad=False)
            self.do_stride = lambda x_in: F.conv2d(
                x_in, self.stride_filter, bias=None, stride=self.stride, groups=self.in_channels
            )
        else:
            self.do_stride = None

    def forward(self, x):
        # 输入通道校验
        assert x.shape[1] == self.in_channels, \
            f"WTConv2d输入通道不匹配：预期{self.in_channels}，实际{x.shape[1]}"

        x_ll_in_levels = []
        x_h_in_levels = []
        shapes_in_levels = []
        curr_x_ll = x

        for i in range(self.wt_levels):
            curr_shape = curr_x_ll.shape
            shapes_in_levels.append(curr_shape)
            # 补齐奇数尺寸
            if (curr_shape[2] % 2 > 0) or (curr_shape[3] % 2 > 0):
                curr_pads = (0, curr_shape[3] % 2, 0, curr_shape[2] % 2)
                curr_x_ll = F.pad(curr_x_ll, curr_pads)

            curr_x = self.wt_function(curr_x_ll)
            curr_x_ll = curr_x[:, :, 0, :, :]

            shape_x = curr_x.shape
            curr_x_tag = curr_x.reshape(shape_x[0], shape_x[1] * 4, shape_x[3], shape_x[4])
            curr_x_tag = self.wavelet_scale[i](self.wavelet_convs[i](curr_x_tag))
            curr_x_tag = curr_x_tag.reshape(shape_x)

            x_ll_in_levels.append(curr_x_tag[:, :, 0, :, :])
            x_h_in_levels.append(curr_x_tag[:, :, 1:4, :, :])

        next_x_ll = 0
        for i in range(self.wt_levels - 1, -1, -1):
            curr_x_ll = x_ll_in_levels.pop()
            curr_x_h = x_h_in_levels.pop()
            curr_shape = shapes_in_levels.pop()

            curr_x_ll = curr_x_ll + next_x_ll
            curr_x = torch.cat([curr_x_ll.unsqueeze(2), curr_x_h], dim=2)
            next_x_ll = self.iwt_function(curr_x)
            next_x_ll = next_x_ll[:, :, :curr_shape[2], :curr_shape[3]]

        x_tag = next_x_ll
        x = self.base_scale(self.base_conv(x))
        x = x + x_tag

        if self.do_stride is not None:
            x = self.do_stride(x)
        return x


class _ScaleModule(nn.Module):
    def __init__(self, dims, init_scale=1.0, init_bias=0):
        super(_ScaleModule, self).__init__()
        self.dims = dims
        self.weight = nn.Parameter(torch.ones(*dims) * init_scale)
        self.bias = None

    def forward(self, x):
        return torch.mul(self.weight, x)


class DCH(nn.Module):
    """使用Haar小波的深度可分离卷积（适配通道缩放）"""
    def __init__(self, in_channels, out_channels, kernel_size=3, wt_type='haar'):
        super(DCH, self).__init__()
        # 适配通道缩放：使用自定义的make_divisible
        self.in_channels = make_divisible(in_channels, 8)
        self.out_channels = make_divisible(out_channels, 8)

        self.depthwise = WTConv2d(
            in_channels=self.in_channels,
            out_channels=self.in_channels,  # 深度卷积保持通道一致
            kernel_size=kernel_size,
            wt_type=wt_type
        )
        self.pointwise = nn.Conv2d(
            self.in_channels, self.out_channels,
            kernel_size=1, stride=1, padding=0, bias=False
        )

    def forward(self, x):
        assert x.shape[1] == self.in_channels, \
            f"DCH输入通道不匹配：预期{self.in_channels}，实际{x.shape[1]}"
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x


class DCB(nn.Module):
    """使用双正交小波的深度可分离卷积（适配通道缩放）"""
    def __init__(self, in_channels, out_channels, kernel_size=3, wt_type='bior2.2'):
        super(DCB, self).__init__()
        # 适配通道缩放：使用自定义的make_divisible
        self.in_channels = make_divisible(in_channels, 8)
        self.out_channels = make_divisible(out_channels, 8)

        self.depthwise = WTConv2d(
            in_channels=self.in_channels,
            out_channels=self.in_channels,
            kernel_size=kernel_size,
            wt_type=wt_type
        )
        self.pointwise = nn.Conv2d(
            self.in_channels, self.out_channels,
            kernel_size=1, stride=1, padding=0, bias=False
        )
        self.bn = nn.BatchNorm2d(self.out_channels)
        self.activation = nn.ReLU()

    def forward(self, x):
        assert x.shape[1] == self.in_channels, \
            f"DCB输入通道不匹配：预期{self.in_channels}，实际{x.shape[1]}"
        x = self.depthwise(x)
        x = self.pointwise(x)
        x = self.bn(x)
        x = self.activation(x)
        return x
    