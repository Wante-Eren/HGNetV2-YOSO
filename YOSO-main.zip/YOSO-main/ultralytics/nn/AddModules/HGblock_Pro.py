import torch
import torch.nn as nn

# ================= 1. 基础组件 =================
def autopad(k, p=None, d=1):
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

class Conv(nn.Module):
    default_act = nn.SiLU()

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

# 经典的无重排 Bottleneck
class StandardBottleneck(nn.Module):
    """极简标准 Bottleneck，去除像素重排，回归纯粹"""
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5, act=nn.SiLU()):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = Conv(c1, c_, k=1, act=act)
        self.cv2 = Conv(c_, c2, k=3, g=g, act=act)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))


# ================= 2. 巅峰理论创新：反应-电报方程求解单元 =================
class ReactionTelegraphPDEUnit(nn.Module):
    """
    双曲型反应-扩散求解单元 (Reaction-Telegraph PDE Unit)
    理论映射：
    1. 扩散项 (\nabla^2 U): 消除红外背景噪声。
    2. 波前项 (|\nabla U|): 提取并保留可见光结构边缘。
    3. 反应项 (R(U)): 局部自激，强力保护红外小目标热源。
    这三个项并行计算，通过动力学系数构成一个统一的偏微分方程增量。
    """
    def __init__(self, dim):
        super().__init__()
        
        # A. 扩散场算子 (Discrete Laplacian for Diffusion)
        self.diffuse_op = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=5, padding=2, groups=dim, bias=False),
            nn.BatchNorm2d(dim)
        )
        
        # B. 光学波前算子 (Wavefront Gradient)
        self.grad_x = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim, bias=False)
        self.grad_y = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim, bias=False)
        self.bn_wave = nn.BatchNorm2d(dim)

        # C. 反应源算子 (Non-linear Reaction Source)
        # 用 1x1 卷积和非线性激活构建局部的化学反应势阱，不涉及空间传播
        self.reaction_op = nn.Sequential(
            nn.Conv2d(dim, dim, 1, bias=False),
            nn.BatchNorm2d(dim),
            nn.SiLU(),
            nn.Conv2d(dim, dim, 1, bias=False),
            nn.BatchNorm2d(dim)
        )

        # D. 动力学系数评估器 (Kinetic Dynamics Estimator)
        # 像素级评估，无全局池化。为每个像素预测 3 个物理力的大小。
        self.dynamics_estimator = nn.Sequential(
            nn.Conv2d(dim, dim // 4, 1, bias=True),
            nn.SiLU(),
            nn.Conv2d(dim // 4, dim * 3, 1) # 输出 D(扩散率), c(波速), K(反应率)
        )
        
        self.proj = nn.Conv2d(dim, dim, 1, bias=False)
        self.bn_out = nn.BatchNorm2d(dim)

    def forward(self, x):
        # --- Step 1: 并行求解方程的三个物理基底 (Parallel Physical Fields) ---
        
        # 1. 离散拉普拉斯扩散 \nabla^2 U \approx smooth(x) - x
        laplacian = self.diffuse_op(x) - x
        
        # 2. 光学波前能量 |\nabla U|
        dx = self.grad_x(x)
        dy = self.grad_y(x)
        wavefront = self.bn_wave(torch.sqrt(dx**2 + dy**2 + 1e-6))
        
        # 3. 局部非线性反应 R(U)
        reaction = self.reaction_op(x)

        # --- Step 2: 像素级动力学参数估计 ---
        rates = self.dynamics_estimator(x)
        D_logits, c_logits, K_logits = torch.split(rates, x.size(1), dim=1)
        
        # 将物理参数约束到合理的数值空间
        D = torch.sigmoid(D_logits)       # 扩散率 (0~1)
        c = torch.sigmoid(c_logits) * 2.0 # 波速增益 (0~2)
        K = torch.sigmoid(K_logits) * 2.0 # 反应增益 (0~2)

        # --- Step 3: 反应-电报方程时间步重构 (Equation Integration) ---
        # 核心：这不是门控，而是三个独立的物理力在一个时间步 \Delta t 内的增量叠加 (Superposition)
        # \Delta U = D * \nabla^2 U + c * |\nabla U| + K * R(U)
        delta_u = D * laplacian + c * wavefront + K * reaction

        # 残差连接严格等价于前向欧拉时间积分: U_{t+1} = U_t + \Delta U
        return x + self.bn_out(self.proj(delta_u))


# ================= 3. 最终网络模块 =================
class HGBlock_UWDU(nn.Module):
    """
    HGBlock + Reaction-Telegraph PDE Solver
    去除像素重排，完全基于反应-电报方程第一性原理的双模态融合架构
    """
    def __init__(self, c1, c2, cm=None, n=4, shortcut=True, act=nn.SiLU()):
        super().__init__()
        if cm is None:
            cm = int(c1 * 0.5)

        self.m = nn.ModuleList()
        # 替换为标准 Bottleneck，纯粹依赖 PDE 单元提取光热特性
        self.m.append(StandardBottleneck(c1, cm, shortcut=shortcut if c1 == cm else False, act=act))
        for _ in range(n - 1):
            self.m.append(StandardBottleneck(cm, cm, shortcut=shortcut, act=act))

        self.sc = Conv(c1 + n * cm, c2 // 2, k=1, act=act)
        self.ec = Conv(c2 // 2, c2, k=1, act=act)

        # 插入大一统反应-电报方程求解器
        self.rt_pde = ReactionTelegraphPDEUnit(dim=c2)

        self.add = shortcut and c1 == c2
        self.act = act

    def forward(self, x):
        y = [x]
        for m in self.m:
            y.append(m(y[-1]))

        concat_feat = torch.cat(y, dim=1)
        out = self.ec(self.sc(concat_feat))

        # 执行像素级的物理法则演化
        out = self.rt_pde(out)

        if self.add:
            out = out + x

        return self.act(out)

if __name__ == '__main__':
    model = HGBlock_UWDU(c1=64, c2=128)
    x = torch.randn(2, 64, 64, 64)
    y = model(x)
    print("输入形状:", x.shape)
    print("输出形状:", y.shape)
    print("V25 大一统反应-电报方程版 准备就绪！")