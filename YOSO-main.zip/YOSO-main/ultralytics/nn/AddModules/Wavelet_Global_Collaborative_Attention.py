import torch
import torch.nn as nn
import torch.nn.functional as F
import pywt

class HaarWavelet(nn.Module):
    """保持输入输出形状一致的Haar小波变换"""
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels
        
        # 基础Haar小波滤波器
        weights = torch.tensor([
            [1, 1, 1, 1],  # LL
            [1, -1, 1, -1], # LH
            [1, 1, -1, -1], # HL
            [1, -1, -1, 1]  # HH
        ], dtype=torch.float32).view(4, 1, 2, 2)
        
        # 复制到所有输入通道
        self.weights = nn.Parameter(weights.repeat(in_channels, 1, 1, 1), requires_grad=False)
        
    def forward(self, x):
        B, C, H, W = x.shape
        pad_h = (2 - H % 2) % 2
        pad_w = (2 - W % 2) % 2
        x = F.pad(x, (0, pad_w, 0, pad_h))
        
        # 分解
        decomposed = F.conv2d(x, self.weights, stride=2, groups=self.in_channels) / 4.0
        
        # 重构（保持原始形状）
        reconstructed = F.conv_transpose2d(
            decomposed, self.weights, 
            stride=2, groups=self.in_channels
        )
        
        # 裁剪多余填充
        return reconstructed[:, :, :H, :W]

class DB2Wavelet(nn.Module):
    """保持输入输出形状一致的DB2小波变换"""
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels
        db2 = pywt.Wavelet('db2')
        
        # 注册滤波器
        self.register_buffer('low_filter', torch.tensor(db2.dec_lo).float().view(1, 1, -1))
        self.padding = len(db2.dec_lo) // 2
        
    def forward(self, x):
        B, C, H, W = x.shape
        pad_h = (2 - H % 2) % 2
        pad_w = (2 - W % 2) % 2
        x_padded = F.pad(x, (0, pad_w, 0, pad_h))
        
        # 分解
        decomposed = F.conv2d(
            x_padded, 
            self.low_filter.repeat(self.in_channels, 1, 1, 1),
            stride=2, groups=self.in_channels, padding=self.padding
        )
        
        # 重构（保持原始形状）
        reconstructed = F.interpolate(
            decomposed, scale_factor=2, 
            mode='bilinear', align_corners=False
        )
        
        # 裁剪多余填充
        return reconstructed[:, :, :H, :W]
class Wavelet_Global_Collaborative_Attention(nn.Module):
    """两进一出的多模态小波融合模块"""
    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        
    def forward(self,x):
        ir = x[0]
        vis = x[1]
        return x[0]+x[1]
