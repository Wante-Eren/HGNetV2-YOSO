import torch.nn as nn
import torch

class SE_Block(nn.Module):
    def __init__(self, ch_in, reduction=16):
        super(SE_Block, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(ch_in, ch_in // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(ch_in // reduction, ch_in, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)

class MF(nn.Module):
    def __init__(self, c1, c2, reduction=16):
        super(MF, self).__init__()
        self.mask_map_r = nn.Conv2d(c1//2, 1, 1, 1, 0, bias=True)
        self.mask_map_i = nn.Conv2d(c1//2, 1, 1, 1, 0, bias=True)
        self.softmax = nn.Softmax(-1)
        self.bottleneck1 = nn.Conv2d(c1//2, c2//2, 3, 1, 1, bias=False)
        self.bottleneck2 = nn.Conv2d(c1//2, c2//2, 3, 1, 1, bias=False)
        self.se = SE_Block(c2, reduction)

    def forward(self, x):
        x_left_ori,x_right_ori = x[:, :3, :, :], x[:, 3:, :, :]
        x_left = x_left_ori * 0.5
        x_right = x_right_ori * 0.5

        x_mask_left = torch.mul(self.mask_map_r(x_left), x_left)
        x_mask_right = torch.mul(self.mask_map_i(x_right), x_right)

        out_IR = self.bottleneck1(x_mask_right + x_right_ori)
        out_RGB = self.bottleneck2(x_mask_left + x_left_ori)  # RGB
        out = self.se(torch.cat([out_RGB, out_IR], 1))

        return out
    
class IN(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x


class Multiin(nn.Module):
    """多模态输入分离模块"""
    def __init__(self, out=1):
        super().__init__()
        if out not in (1, 2):
            raise ValueError(f"Multiin模块的out参数无效: {out} (必须是1或2)")
        self.out = out
        self.channel = 3  # 输出通道数固定为3
    
    def forward(self, x):
        """分离多模态输入"""
        # 确保输入有有效通道数
        if x.size(1) == 0:
            raise RuntimeError(f"Multiin模块收到无效输入: 通道数为0 (形状: {x.shape})")
        
        # 双模态输入 (6通道)
        if x.size(1) == 6:
            if self.out == 1:
                return x[:, :3, :, :]  # 前3个通道
            else:
                return x[:, 3:, :, :]  # 后3个通道
        
        # 单模态输入 (3通道)
        elif x.size(1) == 3:
            return x
        
        # 无效输入
        else:
            raise RuntimeError(
                f"Multiin模块收到无效输入: 通道数={x.size(1)} (期望3或6)\n"
                f"输入形状: {x.shape}\n"
                f"模块配置: out={self.out}"
            )